-- ========================================================
-- Taqniya SMS Database Backup (FULL)
-- Archive: backup_2026-09-27_13-05-27_full.zip
-- Generated: 2026-09-27T11:05:27.548Z
-- ========================================================

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `academic_stages`;
CREATE TABLE `academic_stages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_index` smallint NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stages_name` (`name`),
  KEY `idx_stages_order_index` (`order_index`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `academic_stages` (`id`, `name`, `order_index`, `created_at`, `updated_at`, `deleted_at`) VALUES
(218, 'مرحلة الروضة', 1, '2026-09-27 11:02:58', '2026-09-27 11:02:58', NULL),
(219, 'المرحلة الابتدائية', 2, '2026-09-27 11:02:58', '2026-09-27 11:02:58', NULL),
(220, 'المرحلة الإعدادية', 3, '2026-09-27 11:02:58', '2026-09-27 11:02:58', NULL),
(221, 'المرحلة الثانوية', 4, '2026-09-27 11:02:58', '2026-09-27 11:02:58', NULL);

DROP TABLE IF EXISTS `academic_terms`;
CREATE TABLE `academic_terms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `term_number` tinyint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_terms_name` (`name`),
  UNIQUE KEY `uq_terms_number` (`term_number`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `academic_terms` (`id`, `name`, `term_number`, `created_at`, `updated_at`, `deleted_at`) VALUES
(147, 'الفصل الدراسي الأول', 1, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(148, 'الفصل الدراسي الثاني', 2, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(149, 'الفصل الدراسي الثالث', 3, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL);

DROP TABLE IF EXISTS `academic_years`;
CREATE TABLE `academic_years` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_active` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_academic_years_name` (`name`),
  KEY `idx_academic_years_is_active` (`is_active`),
  KEY `idx_academic_years_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `academic_years` (`id`, `name`, `start_date`, `end_date`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(193, '2026-2027', '2026-09-01 00:00:00', '2027-06-30 00:00:00', 1, '2026-09-27 11:02:58', '2026-09-27 11:02:58', NULL);

DROP TABLE IF EXISTS `assignments`;
CREATE TABLE `assignments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `academic_year_id` bigint unsigned NOT NULL,
  `academic_term_id` bigint unsigned NOT NULL,
  `class_section_id` bigint unsigned NOT NULL,
  `teaching_assignment_id` bigint unsigned NOT NULL,
  `created_by_user_id` bigint unsigned NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `assigned_date` date NOT NULL,
  `due_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_assignments_section_term` (`class_section_id`,`academic_term_id`),
  KEY `idx_assignments_teaching` (`teaching_assignment_id`),
  KEY `idx_assignments_academic_year` (`academic_year_id`),
  KEY `idx_assignments_due_date` (`due_date`),
  KEY `fk_assignments_term_id` (`academic_term_id`),
  KEY `fk_assignments_created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `fk_assignments_class_section_id` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_assignments_created_by_user_id` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_assignments_teaching_assignment_id` FOREIGN KEY (`teaching_assignment_id`) REFERENCES `teaching_assignments` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_assignments_term_id` FOREIGN KEY (`academic_term_id`) REFERENCES `academic_terms` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_assignments_year_id` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` bigint unsigned DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user_id` (`user_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  KEY `idx_audit_created_at` (`created_at`),
  CONSTRAINT `fk_audit_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2596 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `old_values`, `new_values`, `ip_address`, `user_agent`, `created_at`) VALUES
(2594, 170, 'login_failed', 'User', 170, NULL, '{"reason":"invalid_password","user_code":"ADM-1001"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-09-27 11:03:47'),
(2595, 170, 'login', 'User', 170, NULL, '{"device_name":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-09-27 11:03:58');

DROP TABLE IF EXISTS `class_academic_terms`;
CREATE TABLE `class_academic_terms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `class_id` bigint unsigned NOT NULL,
  `academic_term_id` bigint unsigned NOT NULL,
  `is_active` tinyint NOT NULL DEFAULT '0',
  `is_closed` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_class_term` (`class_id`,`academic_term_id`),
  KEY `idx_class_terms_class` (`class_id`),
  KEY `idx_class_terms_term` (`academic_term_id`),
  KEY `idx_class_terms_active` (`is_active`),
  KEY `idx_class_terms_closed` (`is_closed`),
  CONSTRAINT `fk_class_terms_class_id` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_class_terms_term_id` FOREIGN KEY (`academic_term_id`) REFERENCES `academic_terms` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=285 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `class_academic_terms` (`id`, `class_id`, `academic_term_id`, `is_active`, `is_closed`, `created_at`, `updated_at`, `deleted_at`) VALUES
(246, 231, 147, 1, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(247, 231, 148, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(248, 231, 149, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(249, 232, 147, 1, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(250, 232, 148, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(251, 232, 149, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(252, 233, 147, 1, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(253, 233, 148, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(254, 233, 149, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(255, 234, 147, 1, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(256, 234, 148, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(257, 234, 149, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(258, 235, 147, 1, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(259, 235, 148, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(260, 235, 149, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(261, 236, 147, 1, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(262, 236, 148, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(263, 236, 149, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(264, 237, 147, 1, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(265, 237, 148, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(266, 237, 149, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(267, 238, 147, 1, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(268, 238, 148, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(269, 238, 149, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(270, 239, 147, 1, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(271, 239, 148, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(272, 239, 149, 0, 0, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(273, 240, 147, 1, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(274, 240, 148, 0, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(275, 240, 149, 0, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(276, 241, 147, 1, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(277, 241, 148, 0, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(278, 241, 149, 0, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(279, 242, 147, 1, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(280, 242, 148, 0, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(281, 242, 149, 0, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(282, 243, 147, 1, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(283, 243, 148, 0, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(284, 243, 149, 0, 0, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL);

DROP TABLE IF EXISTS `class_sections`;
CREATE TABLE `class_sections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `class_id` bigint unsigned NOT NULL,
  `section_id` bigint unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_class_sections` (`class_id`,`section_id`),
  KEY `idx_class_sections_class` (`class_id`),
  KEY `idx_class_sections_section` (`section_id`),
  CONSTRAINT `fk_class_sections_class_id` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_class_sections_section_id` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=280 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `class_sections` (`id`, `class_id`, `section_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(254, 231, 206, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(255, 231, 207, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(256, 232, 206, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(257, 232, 207, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(258, 233, 206, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(259, 233, 207, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(260, 234, 206, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(261, 234, 207, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(262, 235, 206, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(263, 235, 207, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(264, 236, 206, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(265, 236, 207, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(266, 237, 206, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(267, 237, 207, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(268, 238, 206, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(269, 238, 207, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(270, 239, 206, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(271, 239, 207, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(272, 240, 206, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(273, 240, 207, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(274, 241, 206, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(275, 241, 207, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(276, 242, 206, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(277, 242, 207, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(278, 243, 206, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL),
(279, 243, 207, '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL);

DROP TABLE IF EXISTS `class_subjects`;
CREATE TABLE `class_subjects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `class_id` bigint unsigned NOT NULL,
  `subject_id` bigint unsigned NOT NULL,
  `class_academic_term_id` bigint unsigned NOT NULL,
  `passing_score` decimal(5,2) NOT NULL DEFAULT '50.00',
  `max_score` decimal(5,2) NOT NULL DEFAULT '100.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `exam_passing_score` decimal(5,2) NOT NULL DEFAULT '30.00',
  `max_coursework_score` decimal(5,2) NOT NULL DEFAULT '40.00',
  `max_exam_score` decimal(5,2) NOT NULL DEFAULT '60.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_class_term_subject` (`class_academic_term_id`,`subject_id`),
  KEY `idx_class_subjects_class` (`class_id`),
  KEY `idx_class_subjects_subject` (`subject_id`),
  KEY `idx_class_subjects_class_term` (`class_academic_term_id`),
  CONSTRAINT `fk_class_subjects_class_id` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_class_subjects_subject_id` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_class_subjects_term_id` FOREIGN KEY (`class_academic_term_id`) REFERENCES `class_academic_terms` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=576 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `class_subjects` (`id`, `class_id`, `subject_id`, `class_academic_term_id`, `passing_score`, `max_score`, `created_at`, `updated_at`, `deleted_at`, `exam_passing_score`, `max_coursework_score`, `max_exam_score`) VALUES
(482, 231, 256, 246, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(483, 231, 257, 246, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(484, 231, 259, 246, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(485, 231, 262, 246, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(486, 232, 256, 249, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(487, 232, 257, 249, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(488, 232, 258, 249, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(489, 232, 259, 249, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(490, 232, 260, 249, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(491, 232, 262, 249, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(492, 233, 256, 252, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(493, 233, 257, 252, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(494, 233, 258, 252, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(495, 233, 259, 252, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(496, 233, 260, 252, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(497, 233, 262, 252, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(498, 234, 256, 255, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(499, 234, 257, 255, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(500, 234, 258, 255, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(501, 234, 259, 255, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(502, 234, 260, 255, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(503, 234, 262, 255, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(504, 235, 256, 258, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(505, 235, 257, 258, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(506, 235, 258, 258, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(507, 235, 259, 258, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(508, 235, 260, 258, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(509, 235, 261, 258, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(510, 235, 262, 258, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(511, 235, 263, 258, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(512, 236, 256, 261, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(513, 236, 257, 261, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(514, 236, 258, 261, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(515, 236, 259, 261, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(516, 236, 260, 261, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(517, 236, 261, 261, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(518, 236, 262, 261, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(519, 236, 263, 261, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(520, 237, 256, 264, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(521, 237, 257, 264, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(522, 237, 258, 264, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(523, 237, 259, 264, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(524, 237, 260, 264, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(525, 237, 261, 264, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(526, 237, 262, 264, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(527, 237, 263, 264, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(528, 238, 256, 267, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(529, 238, 257, 267, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(530, 238, 258, 267, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(531, 238, 259, 267, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(532, 238, 260, 267, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(533, 238, 261, 267, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(534, 238, 262, 267, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(535, 238, 263, 267, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(536, 239, 256, 270, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(537, 239, 257, 270, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(538, 239, 258, 270, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(539, 239, 259, 270, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(540, 239, 260, 270, '"50"', '"100"', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, '"30"', '"40"', '"60"'),
(541, 239, 261, 270, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(542, 239, 262, 270, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(543, 239, 263, 270, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(544, 240, 256, 273, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(545, 240, 257, 273, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(546, 240, 258, 273, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(547, 240, 259, 273, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(548, 240, 260, 273, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(549, 240, 261, 273, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(550, 240, 262, 273, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(551, 240, 263, 273, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(552, 241, 256, 276, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(553, 241, 257, 276, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(554, 241, 258, 276, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(555, 241, 259, 276, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(556, 241, 260, 276, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(557, 241, 261, 276, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(558, 241, 262, 276, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(559, 241, 263, 276, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(560, 242, 256, 279, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(561, 242, 257, 279, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(562, 242, 258, 279, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(563, 242, 259, 279, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(564, 242, 260, 279, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(565, 242, 261, 279, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(566, 242, 262, 279, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(567, 242, 263, 279, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(568, 243, 256, 282, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(569, 243, 257, 282, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(570, 243, 258, 282, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(571, 243, 259, 282, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(572, 243, 260, 282, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(573, 243, 261, 282, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(574, 243, 262, 282, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"'),
(575, 243, 263, 282, '"50"', '"100"', '2026-09-27 11:03:00', '2026-09-27 11:03:00', NULL, '"30"', '"40"', '"60"');

DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stage_id` bigint unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grade_level` smallint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `max_second_round_subjects` smallint NOT NULL DEFAULT '3',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_classes_stage_level` (`stage_id`,`grade_level`),
  KEY `idx_classes_stage_id` (`stage_id`),
  KEY `idx_classes_grade_level` (`grade_level`),
  CONSTRAINT `fk_classes_stage_id` FOREIGN KEY (`stage_id`) REFERENCES `academic_stages` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=244 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `classes` (`id`, `stage_id`, `name`, `grade_level`, `created_at`, `updated_at`, `deleted_at`, `max_second_round_subjects`) VALUES
(231, 218, 'التمهيدي', 1, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(232, 219, 'الصف الأول الابتدائي', 1, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(233, 219, 'الصف الثاني الابتدائي', 2, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(234, 219, 'الصف الثالث الابتدائي', 3, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(235, 219, 'الصف الرابع الابتدائي', 4, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(236, 219, 'الصف الخامس الابتدائي', 5, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(237, 219, 'الصف السادس الابتدائي', 6, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(238, 220, 'الصف الأول الإعدادي', 7, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(239, 220, 'الصف الثاني الإعدادي', 8, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(240, 220, 'الصف الثالث الإعدادي', 9, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(241, 221, 'الصف الأول الثانوي', 10, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(242, 221, 'الصف الثاني الثانوي', 11, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3),
(243, 221, 'الصف الثالث الثانوي', 12, '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL, 3);

DROP TABLE IF EXISTS `guardian_students`;
CREATE TABLE `guardian_students` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `guardian_id` bigint unsigned NOT NULL,
  `student_id` bigint unsigned NOT NULL,
  `is_primary` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_guardian_student` (`guardian_id`,`student_id`),
  KEY `idx_guardian_students_guardian` (`guardian_id`),
  KEY `idx_guardian_students_student` (`student_id`),
  CONSTRAINT `fk_guardian_students_guardian_id` FOREIGN KEY (`guardian_id`) REFERENCES `guardians` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_guardian_students_student_id` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `guardians`;
CREATE TABLE `guardians` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relationship` enum('father','mother','brother','uncle','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'father',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_guardians_user_id` (`user_id`),
  UNIQUE KEY `uq_guardians_phone` (`phone`),
  KEY `idx_guardians_full_name` (`full_name`),
  CONSTRAINT `fk_guardians_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `official_exams`;
CREATE TABLE `official_exams` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `academic_year_id` bigint unsigned NOT NULL,
  `academic_term_id` bigint unsigned NOT NULL,
  `class_id` bigint unsigned NOT NULL,
  `subject_id` bigint unsigned NOT NULL,
  `exam_type` enum('midterm','final','second_round') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'final',
  `exam_date` date NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachments` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_official_exam_schedule` (`academic_year_id`,`academic_term_id`,`class_id`,`subject_id`,`exam_type`),
  KEY `idx_official_exams_lookup` (`academic_year_id`,`academic_term_id`,`class_id`),
  KEY `idx_official_exams_date` (`exam_date`),
  KEY `fk_official_exams_term_id` (`academic_term_id`),
  KEY `fk_official_exams_class_id` (`class_id`),
  KEY `fk_official_exams_subject_id` (`subject_id`),
  CONSTRAINT `fk_official_exams_class_id` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_official_exams_subject_id` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_official_exams_term_id` FOREIGN KEY (`academic_term_id`) REFERENCES `academic_terms` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_official_exams_year_id` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `period_slots`;
CREATE TABLE `period_slots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slot_number` tinyint NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `is_break` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_period_slots_number` (`slot_number`),
  KEY `idx_period_slots_times` (`start_time`,`end_time`),
  KEY `idx_period_slots_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `token_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_used_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tokens_token_hash` (`token_hash`),
  KEY `idx_tokens_user_id` (`user_id`),
  KEY `idx_tokens_expires_at` (`expires_at`),
  CONSTRAINT `fk_tokens_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `personal_access_tokens` (`id`, `user_id`, `token_hash`, `device_name`, `ip_address`, `expires_at`, `created_at`, `last_used_at`) VALUES
(134, 170, '2ff2fe206974ae3260fb3668c5d787eda3835b40e10111f621e0920d8bf9e9b9', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '::1', '2026-09-28 11:03:58', '2026-09-27 11:03:58', '2026-09-27 11:05:28');

DROP TABLE IF EXISTS `promotion_batches`;
CREATE TABLE `promotion_batches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `from_academic_year_id` bigint unsigned NOT NULL,
  `to_academic_year_id` bigint unsigned NOT NULL,
  `executed_by_user_id` bigint unsigned NOT NULL,
  `total_students` int unsigned NOT NULL,
  `total_promoted` int unsigned NOT NULL,
  `total_second_round` int unsigned NOT NULL,
  `total_retained` int unsigned NOT NULL,
  `total_graduated` int unsigned NOT NULL,
  `overall_passing_rate` decimal(5,2) NOT NULL,
  `class_statistics` json NOT NULL,
  `execution_notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_promotion_batch_years` (`from_academic_year_id`,`to_academic_year_id`),
  KEY `idx_promotion_executed_by` (`executed_by_user_id`),
  KEY `idx_promotion_created_at` (`created_at`),
  KEY `fk_promotion_to_year_id` (`to_academic_year_id`),
  CONSTRAINT `fk_promotion_executed_by_user_id` FOREIGN KEY (`executed_by_user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_promotion_from_year_id` FOREIGN KEY (`from_academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_promotion_to_year_id` FOREIGN KEY (`to_academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `quizzes`;
CREATE TABLE `quizzes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `academic_year_id` bigint unsigned NOT NULL,
  `academic_term_id` bigint unsigned NOT NULL,
  `class_section_id` bigint unsigned NOT NULL,
  `teaching_assignment_id` bigint unsigned NOT NULL,
  `created_by_user_id` bigint unsigned NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `quiz_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_quizzes_section_term` (`class_section_id`,`academic_term_id`),
  KEY `idx_quizzes_teaching` (`teaching_assignment_id`),
  KEY `idx_quizzes_academic_year` (`academic_year_id`),
  KEY `idx_quizzes_date` (`quiz_date`),
  KEY `fk_quizzes_term_id` (`academic_term_id`),
  KEY `fk_quizzes_created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `fk_quizzes_class_section_id` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_quizzes_created_by_user_id` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_quizzes_teaching_assignment_id` FOREIGN KEY (`teaching_assignment_id`) REFERENCES `teaching_assignments` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_quizzes_term_id` FOREIGN KEY (`academic_term_id`) REFERENCES `academic_terms` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_quizzes_year_id` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sections`;
CREATE TABLE `sections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sections_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sections` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(206, 'شعبة أ', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(207, 'شعبة ب', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(208, 'شعبة ج', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(209, 'شعبة د', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL);

DROP TABLE IF EXISTS `student_enrollments`;
CREATE TABLE `student_enrollments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `academic_year_id` bigint unsigned NOT NULL,
  `student_id` bigint unsigned NOT NULL,
  `class_id` bigint unsigned NOT NULL,
  `grade_level` smallint NOT NULL,
  `class_section_id` bigint unsigned NOT NULL,
  `seating_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('enrolled','passed','second_round','failed','graduated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enrolled',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_student_year_enrollment` (`academic_year_id`,`student_id`),
  KEY `idx_enrollments_class_id` (`class_id`),
  KEY `idx_enrollments_grade_level` (`academic_year_id`,`grade_level`),
  KEY `idx_enrollments_class_section` (`class_section_id`),
  KEY `idx_enrollments_status` (`status`),
  KEY `idx_enrollments_seating` (`seating_number`),
  KEY `fk_enrollments_student_id` (`student_id`),
  CONSTRAINT `fk_enrollments_class_id` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_enrollments_class_section_id` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_enrollments_student_id` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_enrollments_year_id` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `student_transcripts`;
CREATE TABLE `student_transcripts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `transcript_type` enum('term','annual') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'annual',
  `class_academic_term_id` bigint unsigned DEFAULT NULL,
  `academic_year_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grade_level` smallint NOT NULL,
  `total_score` decimal(7,2) NOT NULL,
  `percentage` decimal(5,2) NOT NULL,
  `final_status` enum('enrolled','passed','second_round','failed','graduated') COLLATE utf8mb4_unicode_ci NOT NULL,
  `rank` smallint DEFAULT NULL,
  `transcript_data` json NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_student_transcript_term` (`student_id`,`academic_year_name`,`transcript_type`,`class_academic_term_id`),
  KEY `idx_transcripts_year_class` (`academic_year_name`,`class_name`),
  KEY `idx_transcripts_status` (`final_status`),
  KEY `fk_transcripts_class_term_id` (`class_academic_term_id`),
  CONSTRAINT `fk_transcripts_class_term_id` FOREIGN KEY (`class_academic_term_id`) REFERENCES `class_academic_terms` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_transcripts_student_id` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `student_transcripts` (`id`, `student_id`, `transcript_type`, `class_academic_term_id`, `academic_year_name`, `class_name`, `section_name`, `grade_level`, `total_score`, `percentage`, `final_status`, `rank`, `transcript_data`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 44, 'term', 216, '2025-2026', 'الصف التمهيدي', 'شعبة (ب)', 1, '"520"', '"86.67"', 'passed', NULL, '{"subjects":[{"status":"passed","max_score":100,"exam_score":53,"subject_id":249,"total_score":83,"subject_name":"الدراسات الاجتماعية","passing_score":50,"max_exam_score":60,"coursework_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":55,"subject_id":246,"total_score":88,"subject_name":"الرياضيات","passing_score":50,"max_exam_score":60,"coursework_score":33,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":55,"subject_id":247,"total_score":85,"subject_name":"العلوم العامة","passing_score":50,"max_exam_score":60,"coursework_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":244,"total_score":97,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":50,"max_exam_score":60,"coursework_score":39,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":52,"subject_id":248,"total_score":86,"subject_name":"اللغة الإنجليزية","passing_score":50,"max_exam_score":60,"coursework_score":34,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":50,"subject_id":245,"total_score":81,"subject_name":"اللغة العربية","passing_score":50,"max_exam_score":60,"coursework_score":31,"max_coursework_score":40,"second_round_details":null}],"frozen_at":"2026-09-24T10:33:57.896Z","term_name":"الفصل الدراسي الأول","class_name":"الصف التمهيدي","percentage":86.67,"student_id":44,"total_score":520,"final_status":"passed","section_name":"شعبة (ب)","student_code":"STU-3004","student_name":"طارق زياد الورفلي","academic_year_name":"2025-2026","max_possible_score":600}', '2026-09-23 12:23:31', '2026-09-24 10:33:58', NULL),
(3, 44, 'term', 217, '2025-2026', 'الصف التمهيدي', 'شعبة (ب)', 1, '"533"', '"88.83"', 'passed', NULL, '{"subjects":[{"status":"passed","max_score":100,"exam_score":50,"subject_id":249,"total_score":80,"subject_name":"الدراسات الاجتماعية","passing_score":50,"max_exam_score":60,"coursework_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":52,"subject_id":246,"total_score":85,"subject_name":"الرياضيات","passing_score":50,"max_exam_score":60,"coursework_score":33,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":51,"subject_id":247,"total_score":86,"subject_name":"العلوم العامة","passing_score":50,"max_exam_score":60,"coursework_score":35,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":244,"total_score":97,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":50,"max_exam_score":60,"coursework_score":39,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":56,"subject_id":248,"total_score":96,"subject_name":"اللغة الإنجليزية","passing_score":50,"max_exam_score":60,"coursework_score":40,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":54,"subject_id":245,"total_score":89,"subject_name":"اللغة العربية","passing_score":50,"max_exam_score":60,"coursework_score":35,"max_coursework_score":40,"second_round_details":null}],"frozen_at":"2026-09-24T10:55:58.094Z","term_name":"الفصل الدراسي الثاني","class_name":"الصف التمهيدي","percentage":88.83,"student_id":44,"total_score":533,"final_status":"passed","section_name":"شعبة (ب)","student_code":"STU-3004","student_name":"طارق زياد الورفلي","academic_year_name":"2025-2026","max_possible_score":600}', '2026-09-24 10:55:58', '2026-09-24 10:55:58', NULL),
(4, 44, 'annual', NULL, '2025-2026', 'الصف التمهيدي', 'شعبة (ب)', 1, '"1053"', '"87.75"', 'passed', NULL, '{"subjects":[{"status":"passed","max_score":200,"total_score":163,"subject_name":"الدراسات الاجتماعية","passing_score":100},{"status":"passed","max_score":200,"total_score":173,"subject_name":"الرياضيات","passing_score":100},{"status":"passed","max_score":200,"total_score":171,"subject_name":"العلوم العامة","passing_score":100},{"status":"passed","max_score":200,"total_score":194,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":100},{"status":"passed","max_score":200,"total_score":182,"subject_name":"اللغة الإنجليزية","passing_score":100},{"status":"passed","max_score":200,"total_score":170,"subject_name":"اللغة العربية","passing_score":100}],"frozen_at":"2026-09-24T11:49:04.073Z","class_name":"الصف التمهيدي","percentage":87.75,"student_id":44,"total_score":1053,"final_status":"passed","section_name":"شعبة (ب)","student_code":"STU-3004","student_name":"طارق زياد الورفلي","annual_summary":true,"terms_included":2,"academic_year_name":"2025-2026","max_possible_score":1200,"student_term_transcripts":[{"id":1,"term_name":"الفصل الدراسي الأول","percentage":86.67,"total_score":520,"transcript_data":{"subjects":[{"status":"passed","max_score":100,"exam_score":53,"subject_id":249,"total_score":83,"subject_name":"الدراسات الاجتماعية","passing_score":50,"max_exam_score":60,"coursework_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":55,"subject_id":246,"total_score":88,"subject_name":"الرياضيات","passing_score":50,"max_exam_score":60,"coursework_score":33,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":55,"subject_id":247,"total_score":85,"subject_name":"العلوم العامة","passing_score":50,"max_exam_score":60,"coursework_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":244,"total_score":97,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":50,"max_exam_score":60,"coursework_score":39,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":52,"subject_id":248,"total_score":86,"subject_name":"اللغة الإنجليزية","passing_score":50,"max_exam_score":60,"coursework_score":34,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":50,"subject_id":245,"total_score":81,"subject_name":"اللغة العربية","passing_score":50,"max_exam_score":60,"coursework_score":31,"max_coursework_score":40,"second_round_details":null}],"frozen_at":"2026-09-24T10:33:57.896Z","term_name":"الفصل الدراسي الأول","class_name":"الصف التمهيدي","percentage":86.67,"student_id":44,"total_score":520,"final_status":"passed","section_name":"شعبة (ب)","student_code":"STU-3004","student_name":"طارق زياد الورفلي","academic_year_name":"2025-2026","max_possible_score":600},"class_academic_term_id":216},{"id":3,"term_name":"الفصل الدراسي الثاني","percentage":88.83,"total_score":533,"transcript_data":{"subjects":[{"status":"passed","max_score":100,"exam_score":50,"subject_id":249,"total_score":80,"subject_name":"الدراسات الاجتماعية","passing_score":50,"max_exam_score":60,"coursework_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":52,"subject_id":246,"total_score":85,"subject_name":"الرياضيات","passing_score":50,"max_exam_score":60,"coursework_score":33,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":51,"subject_id":247,"total_score":86,"subject_name":"العلوم العامة","passing_score":50,"max_exam_score":60,"coursework_score":35,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":244,"total_score":97,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":50,"max_exam_score":60,"coursework_score":39,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":56,"subject_id":248,"total_score":96,"subject_name":"اللغة الإنجليزية","passing_score":50,"max_exam_score":60,"coursework_score":40,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":54,"subject_id":245,"total_score":89,"subject_name":"اللغة العربية","passing_score":50,"max_exam_score":60,"coursework_score":35,"max_coursework_score":40,"second_round_details":null}],"frozen_at":"2026-09-24T10:55:58.094Z","term_name":"الفصل الدراسي الثاني","class_name":"الصف التمهيدي","percentage":88.83,"student_id":44,"total_score":533,"final_status":"passed","section_name":"شعبة (ب)","student_code":"STU-3004","student_name":"طارق زياد الورفلي","academic_year_name":"2025-2026","max_possible_score":600},"class_academic_term_id":217}]}', '2026-09-24 11:08:49', '2026-09-24 11:49:04', NULL),
(5, 44, 'term', 223, '2026-2027', 'الصف الثاني الابتدائي', 'شعبة (ب)', 2, '"633.5"', '"87.99"', 'second_round', NULL, '{"subjects":[{"status":"failed","max_score":100,"exam_score":29.5,"subject_id":249,"total_score":59.5,"subject_name":"الدراسات الاجتماعية","passing_score":50,"max_exam_score":60,"coursework_score":30,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":120,"exam_score":65,"subject_id":246,"total_score":110,"subject_name":"الرياضيات","passing_score":60,"max_exam_score":70,"coursework_score":45,"exam_passing_score":40,"max_coursework_score":50,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":55,"subject_id":247,"total_score":90,"subject_name":"العلوم العامة","passing_score":50,"max_exam_score":60,"coursework_score":35,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":244,"total_score":98,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":50,"max_exam_score":60,"coursework_score":40,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":56,"subject_id":248,"total_score":90,"subject_name":"اللغة الإنجليزية","passing_score":50,"max_exam_score":60,"coursework_score":34,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":56,"subject_id":245,"total_score":89,"subject_name":"اللغة العربية","passing_score":50,"max_exam_score":60,"coursework_score":33,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":250,"total_score":97,"subject_name":"تقنية المعلومات والحاسوب","passing_score":50,"max_exam_score":60,"coursework_score":39,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null}],"frozen_at":"2026-09-24T16:24:30.722Z","term_name":"الفصل الدراسي الثاني","class_name":"الصف الثاني الابتدائي","percentage":87.99,"student_id":44,"total_score":633.5,"final_status":"second_round","section_name":"شعبة (ب)","student_code":"STU-3004","student_name":"طارق زياد الورفلي","academic_year_name":"2026-2027","max_possible_score":720}', '2026-09-24 16:24:31', '2026-09-24 16:24:31', NULL),
(6, 44, 'term', 222, '2026-2027', 'الصف الثاني الابتدائي', 'شعبة (ب)', 2, '"665"', '"92.36"', 'passed', NULL, '{"subjects":[{"status":"passed","max_score":100,"exam_score":50,"subject_id":249,"total_score":85,"subject_name":"الدراسات الاجتماعية","passing_score":50,"max_exam_score":60,"coursework_score":35,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":120,"exam_score":65,"subject_id":246,"total_score":110,"subject_name":"الرياضيات","passing_score":60,"max_exam_score":70,"coursework_score":45,"exam_passing_score":40,"max_coursework_score":50,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":55,"subject_id":247,"total_score":90,"subject_name":"العلوم العامة","passing_score":50,"max_exam_score":60,"coursework_score":35,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":59,"subject_id":244,"total_score":97,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":50,"max_exam_score":60,"coursework_score":38,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":55,"subject_id":248,"total_score":91,"subject_name":"اللغة الإنجليزية","passing_score":50,"max_exam_score":60,"coursework_score":36,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":57,"subject_id":245,"total_score":96,"subject_name":"اللغة العربية","passing_score":50,"max_exam_score":60,"coursework_score":39,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":250,"total_score":96,"subject_name":"تقنية المعلومات والحاسوب","passing_score":50,"max_exam_score":60,"coursework_score":38,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null}],"frozen_at":"2026-09-24T16:28:09.518Z","term_name":"الفصل الدراسي الأول","class_name":"الصف الثاني الابتدائي","percentage":92.36,"student_id":44,"total_score":665,"final_status":"passed","section_name":"شعبة (ب)","student_code":"STU-3004","student_name":"طارق زياد الورفلي","academic_year_name":"2026-2027","max_possible_score":720}', '2026-09-24 16:28:10', '2026-09-24 16:28:10', NULL),
(7, 44, 'annual', NULL, '2026-2027', 'الصف الثاني الابتدائي', 'شعبة (ب)', 2, '"1298.5"', '"90.17"', 'passed', NULL, '{"subjects":[{"status":"passed","max_score":200,"exam_score":79.5,"total_score":144.5,"subject_name":"الدراسات الاجتماعية","passing_score":100,"max_exam_score":120,"coursework_score":65,"exam_passing_score":60,"max_coursework_score":80,"terms_failed_exam_count":1},{"status":"passed","max_score":240,"exam_score":130,"total_score":220,"subject_name":"الرياضيات","passing_score":120,"max_exam_score":140,"coursework_score":90,"exam_passing_score":80,"max_coursework_score":100,"terms_failed_exam_count":0},{"status":"passed","max_score":200,"exam_score":110,"total_score":180,"subject_name":"العلوم العامة","passing_score":100,"max_exam_score":120,"coursework_score":70,"exam_passing_score":60,"max_coursework_score":80,"terms_failed_exam_count":0},{"status":"passed","max_score":200,"exam_score":117,"total_score":195,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":100,"max_exam_score":120,"coursework_score":78,"exam_passing_score":60,"max_coursework_score":80,"terms_failed_exam_count":0},{"status":"passed","max_score":200,"exam_score":111,"total_score":181,"subject_name":"اللغة الإنجليزية","passing_score":100,"max_exam_score":120,"coursework_score":70,"exam_passing_score":60,"max_coursework_score":80,"terms_failed_exam_count":0},{"status":"passed","max_score":200,"exam_score":113,"total_score":185,"subject_name":"اللغة العربية","passing_score":100,"max_exam_score":120,"coursework_score":72,"exam_passing_score":60,"max_coursework_score":80,"terms_failed_exam_count":0},{"status":"passed","max_score":200,"exam_score":116,"total_score":193,"subject_name":"تقنية المعلومات والحاسوب","passing_score":100,"max_exam_score":120,"coursework_score":77,"exam_passing_score":60,"max_coursework_score":80,"terms_failed_exam_count":0}],"frozen_at":"2026-09-24T16:38:54.639Z","class_name":"الصف الثاني الابتدائي","percentage":90.17,"student_id":44,"total_score":1298.5,"final_status":"passed","section_name":"شعبة (ب)","student_code":"STU-3004","student_name":"طارق زياد الورفلي","annual_summary":true,"terms_included":2,"academic_year_name":"2026-2027","max_possible_score":1440,"student_term_transcripts":[{"id":6,"term_name":"الفصل الدراسي الأول","percentage":92.36,"total_score":665,"transcript_data":{"subjects":[{"status":"passed","max_score":100,"exam_score":50,"subject_id":249,"total_score":85,"subject_name":"الدراسات الاجتماعية","passing_score":50,"max_exam_score":60,"coursework_score":35,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":120,"exam_score":65,"subject_id":246,"total_score":110,"subject_name":"الرياضيات","passing_score":60,"max_exam_score":70,"coursework_score":45,"exam_passing_score":40,"max_coursework_score":50,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":55,"subject_id":247,"total_score":90,"subject_name":"العلوم العامة","passing_score":50,"max_exam_score":60,"coursework_score":35,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":59,"subject_id":244,"total_score":97,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":50,"max_exam_score":60,"coursework_score":38,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":55,"subject_id":248,"total_score":91,"subject_name":"اللغة الإنجليزية","passing_score":50,"max_exam_score":60,"coursework_score":36,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":57,"subject_id":245,"total_score":96,"subject_name":"اللغة العربية","passing_score":50,"max_exam_score":60,"coursework_score":39,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":250,"total_score":96,"subject_name":"تقنية المعلومات والحاسوب","passing_score":50,"max_exam_score":60,"coursework_score":38,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null}],"frozen_at":"2026-09-24T16:28:09.518Z","term_name":"الفصل الدراسي الأول","class_name":"الصف الثاني الابتدائي","percentage":92.36,"student_id":44,"total_score":665,"final_status":"passed","section_name":"شعبة (ب)","student_code":"STU-3004","student_name":"طارق زياد الورفلي","academic_year_name":"2026-2027","max_possible_score":720},"class_academic_term_id":222},{"id":5,"term_name":"الفصل الدراسي الثاني","percentage":87.99,"total_score":633.5,"transcript_data":{"subjects":[{"status":"failed","max_score":100,"exam_score":29.5,"subject_id":249,"total_score":59.5,"subject_name":"الدراسات الاجتماعية","passing_score":50,"max_exam_score":60,"coursework_score":30,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":120,"exam_score":65,"subject_id":246,"total_score":110,"subject_name":"الرياضيات","passing_score":60,"max_exam_score":70,"coursework_score":45,"exam_passing_score":40,"max_coursework_score":50,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":55,"subject_id":247,"total_score":90,"subject_name":"العلوم العامة","passing_score":50,"max_exam_score":60,"coursework_score":35,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":244,"total_score":98,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":50,"max_exam_score":60,"coursework_score":40,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":56,"subject_id":248,"total_score":90,"subject_name":"اللغة الإنجليزية","passing_score":50,"max_exam_score":60,"coursework_score":34,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":56,"subject_id":245,"total_score":89,"subject_name":"اللغة العربية","passing_score":50,"max_exam_score":60,"coursework_score":33,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":250,"total_score":97,"subject_name":"تقنية المعلومات والحاسوب","passing_score":50,"max_exam_score":60,"coursework_score":39,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null}],"frozen_at":"2026-09-24T16:24:30.722Z","term_name":"الفصل الدراسي الثاني","class_name":"الصف الثاني الابتدائي","percentage":87.99,"student_id":44,"total_score":633.5,"final_status":"second_round","section_name":"شعبة (ب)","student_code":"STU-3004","student_name":"طارق زياد الورفلي","academic_year_name":"2026-2027","max_possible_score":720},"class_academic_term_id":223}],"enable_annual_exam_compensation":true}', '2026-09-24 16:38:55', '2026-09-24 16:38:55', NULL),
(8, 46, 'term', 231, '2026-2027', 'الصف الخامس الابتدائي', 'شعبة (أ)', 5, '"693"', '"99"', 'passed', NULL, '{"subjects":[{"status":"passed","max_score":100,"exam_score":60,"subject_id":249,"total_score":98,"subject_name":"الدراسات الاجتماعية","passing_score":50,"max_exam_score":60,"coursework_score":38,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":60,"subject_id":246,"total_score":100,"subject_name":"الرياضيات","passing_score":50,"max_exam_score":60,"coursework_score":40,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":60,"subject_id":247,"total_score":100,"subject_name":"العلوم العامة","passing_score":50,"max_exam_score":60,"coursework_score":40,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":60,"subject_id":244,"total_score":100,"subject_name":"القرآن الكريم والتربية الإسلامية","passing_score":50,"max_exam_score":60,"coursework_score":40,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":59,"subject_id":248,"total_score":99,"subject_name":"اللغة الإنجليزية","passing_score":50,"max_exam_score":60,"coursework_score":40,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":58,"subject_id":245,"total_score":96,"subject_name":"اللغة العربية","passing_score":50,"max_exam_score":60,"coursework_score":38,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null},{"status":"passed","max_score":100,"exam_score":60,"subject_id":250,"total_score":100,"subject_name":"تقنية المعلومات والحاسوب","passing_score":50,"max_exam_score":60,"coursework_score":40,"exam_passing_score":30,"max_coursework_score":40,"second_round_details":null}],"frozen_at":"2026-09-24T21:39:39.764Z","term_name":"الفصل الدراسي الأول","class_name":"الصف الخامس الابتدائي","percentage":99,"student_id":46,"total_score":693,"final_status":"passed","section_name":"شعبة (أ)","student_code":"STU-3005","student_name":"قيس النفاتي شنشوب","academic_year_name":"2026-2027","max_possible_score":700}', '2026-09-24 21:39:40', '2026-09-24 21:39:40', NULL);

DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('male','female') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_students_user_id` (`user_id`),
  KEY `idx_students_full_name` (`full_name`),
  CONSTRAINT `fk_students_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `subjects`;
CREATE TABLE `subjects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_subjects_name` (`name`),
  UNIQUE KEY `uq_subjects_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=264 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `subjects` (`id`, `name`, `code`, `created_at`, `updated_at`, `deleted_at`) VALUES
(256, 'اللغة العربية', 'ARAB', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(257, 'اللغة الإنجليزية', 'ENG', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(258, 'العلوم', 'SCI', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(259, 'الرياضيات', 'MATH', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(260, 'الحاسوب', 'IT', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(261, 'الجغرافيا', 'GEO', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(262, 'التربية الإسلامية', 'ISLAM', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL),
(263, 'التاريخ', 'HIST', '2026-09-27 11:02:59', '2026-09-27 11:02:59', NULL);

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specialization` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_teachers_user_id` (`user_id`),
  KEY `idx_teachers_full_name` (`full_name`),
  CONSTRAINT `fk_teachers_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `teaching_assignments`;
CREATE TABLE `teaching_assignments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `academic_year_id` bigint unsigned NOT NULL,
  `class_section_id` bigint unsigned NOT NULL,
  `subject_id` bigint unsigned NOT NULL,
  `teacher_id` bigint unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_teaching_assignment` (`academic_year_id`,`class_section_id`,`subject_id`),
  KEY `idx_teaching_teacher` (`teacher_id`),
  KEY `idx_teaching_class_section` (`class_section_id`),
  KEY `idx_teaching_subject` (`subject_id`),
  CONSTRAINT `fk_teaching_class_section_id` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_teaching_subject_id` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_teaching_teacher_id` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_teaching_year_id` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `timetable_slots`;
CREATE TABLE `timetable_slots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `academic_year_id` bigint unsigned NOT NULL,
  `class_section_id` bigint unsigned NOT NULL,
  `day_of_week` enum('saturday','sunday','monday','tuesday','wednesday','thursday') COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_slot_id` bigint unsigned NOT NULL,
  `teaching_assignment_id` bigint unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_timetable_section_slot` (`academic_year_id`,`class_section_id`,`day_of_week`,`period_slot_id`),
  KEY `idx_timetable_teacher_conflict` (`academic_year_id`,`day_of_week`,`period_slot_id`,`teaching_assignment_id`),
  KEY `idx_timetable_class_section` (`class_section_id`),
  KEY `fk_timetable_period_slot_id` (`period_slot_id`),
  KEY `fk_timetable_teaching_assignment_id` (`teaching_assignment_id`),
  CONSTRAINT `fk_timetable_class_section_id` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_timetable_period_slot_id` FOREIGN KEY (`period_slot_id`) REFERENCES `period_slots` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_timetable_teaching_assignment_id` FOREIGN KEY (`teaching_assignment_id`) REFERENCES `teaching_assignments` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_timetable_year_id` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `timetable_slots` (`id`, `academic_year_id`, `class_section_id`, `day_of_week`, `period_slot_id`, `teaching_assignment_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(19, 63, 63, 'sunday', 2, 77, '2026-09-14 15:18:13', '2026-09-14 16:29:46', NULL),
(20, 63, 63, 'monday', 6, 77, '2026-09-14 15:18:26', '2026-09-14 16:25:29', '2026-09-14 16:25:29'),
(23, 63, 63, 'sunday', 4, 77, '2026-09-14 16:26:10', '2026-09-14 16:26:10', NULL),
(26, 63, 65, 'sunday', 3, 42, '2026-09-14 16:30:43', '2026-09-14 16:30:43', NULL),
(27, 63, 78, 'sunday', 6, 80, '2026-09-14 17:05:45', '2026-09-14 17:05:45', NULL),
(28, 63, 78, 'sunday', 7, 80, '2026-09-14 17:05:48', '2026-09-14 17:05:48', NULL),
(29, 63, 78, 'monday', 2, 80, '2026-09-14 17:06:27', '2026-09-14 17:06:27', NULL),
(30, 182, 236, 'sunday', 2, 84, '2026-09-19 06:59:09', '2026-09-19 06:59:09', NULL),
(31, 182, 236, 'sunday', 3, 84, '2026-09-19 06:59:15', '2026-09-19 06:59:15', NULL),
(32, 182, 237, 'sunday', 4, 85, '2026-09-19 06:59:34', '2026-09-19 06:59:34', NULL),
(33, 182, 237, 'sunday', 6, 85, '2026-09-19 06:59:37', '2026-09-19 06:59:37', NULL);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_type` enum('admin','teacher','student','parent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_user_code` (`user_code`),
  KEY `idx_users_role_type` (`role_type`),
  KEY `idx_users_is_active` (`is_active`),
  KEY `idx_users_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `user_code`, `password`, `role_type`, `is_active`, `last_login_at`, `created_at`, `updated_at`, `deleted_at`) VALUES
(169, 'ADM-0001', '$2b$10$QLFujxh7RAYQlU3xx4eFbeCovx09eTtAeMC9EDdZnvx72ibwsdggW', 'admin', 1, NULL, '2026-09-27 11:02:58', '2026-09-27 11:02:58', NULL),
(170, 'ADM-1001', '$2b$10$rCQPMKKQTgUzSiW.n0w36eB2O4H61Wiy75cdPeHziuOkhZQZvvnkK', 'admin', 1, '2026-09-27 11:03:58', '2026-09-27 11:02:58', '2026-09-27 11:03:58', NULL),
(171, 'admin', '$2b$10$rCQPMKKQTgUzSiW.n0w36eB2O4H61Wiy75cdPeHziuOkhZQZvvnkK', 'admin', 1, NULL, '2026-09-27 11:02:58', '2026-09-27 11:02:58', NULL);

SET FOREIGN_KEY_CHECKS=1;
